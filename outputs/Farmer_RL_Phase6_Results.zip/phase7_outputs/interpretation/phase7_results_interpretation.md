# Phase 7 Results Interpretation

## Overall performance

The Proximal Policy Optimisation agent achieved an average total reward of
809.655, while the random crop-selection policy achieved
230.940. This represents a PPO difference of
250.59% relative to the random baseline. Based on average
episode reward, the better-performing strategy was the PPO.

## Farmer savings

The PPO policy produced average final savings of 134,641,631,968.20, compared
with 38,462,603,300.98 under random crop selection. The difference was
250.06%. The policy with the higher average final savings was
the PPO.

## Net income

Average total net income was 134,641,531,968.20 for PPO and
38,462,503,300.98 for the random policy. The PPO difference relative to
the baseline was 250.06%.

## Farm survival and financial risk

The PPO agent survived for an average of 18.10 years, while the
random policy survived for 12.82 years. The PPO bankruptcy
rate was 10.00%, compared with 38.00% for
random crop selection.

## Crop-selection behaviour

The crop most frequently selected by PPO was
Wheat, accounting for
88.67% of PPO decisions. The PPO crop
with the highest observed average net income was
Wheat, with an average net income of
8,117,911,480.14.

## Interpretation

The comparison indicates whether PPO learned a decision strategy that is more
effective than choosing crops randomly. Higher rewards, savings and net income
show improved economic performance. A lower bankruptcy rate indicates better
financial risk management. Crop-frequency results show which crops the agent
preferred under the simulated rainfall, market-price and crop-rotation
conditions.

These results should be interpreted within the limitations of the dataset and
the custom FarmEnv assumptions. The model estimates decisions from historical
data and simulated uncertainty; it does not guarantee real-world farm profit.
Future work should include region-specific soil information, weather
forecasts, crop demand, water availability and independent field validation.